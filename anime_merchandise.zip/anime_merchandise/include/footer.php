<footer>
    <p>&copy; <?php echo date('Y'); ?>  anime merchandise</p>
</footer>
</body>
</html>
